package com.example.dungeon.core;

import com.example.dungeon.model.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;
import java.nio.charset.StandardCharsets;
public class Game {
    private final GameState state = new GameState();
    private final Map<String, Command> commands = new LinkedHashMap<>();

    static {
        WorldInfo.touch("Game");
    }

    public Game() {
        registerCommands();
        bootstrapWorld();
    }

    private void registerCommands() {
        commands.put("help", (ctx, a) -> System.out.println("Команды: " + String.join(", ", commands.keySet())));
        commands.put("use", (ctx, a) -> {
    if (a.isEmpty()) {
        throw new InvalidCommandException("Синтаксис: use <название предмета>");
    }
    String want = String.join(" ", a)
            .replaceAll("[\"'<>]", "")
            .trim()
            .toLowerCase(Locale.ROOT);

    var inv = ctx.getPlayer().getInventory();
    Item found = null;
    for (Item it : inv) {
        String have = it.getName().trim().toLowerCase(Locale.ROOT);
        if (have.equals(want) || have.startsWith(want)) {
            found = it; break;
        }
    }
    if (found == null) {
        throw new InvalidCommandException("У вас нет предмета: " + String.join(" ", a));
    }

    // apply возвращает void → просто вызываем
    found.apply(ctx);              // эффект предмета (зелье лечит и печатает сообщение)

    // Одноразовые предметы убираем из инвентаря.
    // В нашем мире одноразовым является зелье.
    if (found instanceof Potion) {
        inv.remove(found);
    }
});
        commands.put("gc-stats", (ctx, a) -> {
            Runtime rt = Runtime.getRuntime();
            long free = rt.freeMemory(), total = rt.totalMemory(), used = total - free;
            System.out.println("Память: used=" + used + " free=" + free + " total=" + total);
        });
        commands.put("look", (ctx, a) -> System.out.println(ctx.getCurrent().describe()));
        commands.put("move", (ctx, a) -> {
    if (a.size() != 1) {
        throw new InvalidCommandException("Синтаксис: move <north|south|east|west>");
    }
    String dir = a.get(0).toLowerCase(Locale.ROOT);

    Room cur = ctx.getCurrent();
    Room next = cur.getNeighbors().get(dir);
    if (next == null) {
        throw new InvalidCommandException("Туда пройти нельзя: " + dir);
    }

    ctx.setCurrent(next);
    System.out.println("Вы перешли в новую локацию:");
System.out.println(next.describe());
});
        commands.put("take", (ctx, a) -> {
    if (a.isEmpty()) {
        throw new InvalidCommandException("Синтаксис: take <название предмета>");
    }

    // собрали аргументы и вычистили кавычки/уголки
    String want = String.join(" ", a)
            .replaceAll("[\"'<>]", "")
            .trim()
            .toLowerCase(Locale.ROOT);

    Room cur = ctx.getCurrent();
    Item found = null;
    for (Item it : cur.getItems()) {
        String have = it.getName().trim().toLowerCase(Locale.ROOT);
        if (have.equals(want) || have.startsWith(want)) { // допускаем неполное совпадение
            found = it;
            break;
        }
    }

    if (found == null) {
        throw new InvalidCommandException("Здесь нет предмета: " + String.join(" ", a));
    }

    cur.getItems().remove(found);
    ctx.getPlayer().getInventory().add(found);
    System.out.println("Вы взяли: " + found.getName());
});
        commands.put("inventory", (ctx, a) -> {
    var inv = ctx.getPlayer().getInventory();
    if (inv.isEmpty()) {
        System.out.println("Инвентарь пуст.");
        return;
    }

    // Группируем по типу предмета (имя класса) и сортируем имена
    var grouped = inv.stream()
        .collect(java.util.stream.Collectors.groupingBy(
            it -> it.getClass().getSimpleName(),
            java.util.LinkedHashMap::new,
            java.util.stream.Collectors.mapping(
                Item::getName,
                java.util.stream.Collectors.collectingAndThen(
                    java.util.stream.Collectors.toList(),
                    list -> { list.sort(java.util.Comparator.naturalOrder()); return list; }
                )
            )
        ));

    grouped.forEach((type, names) -> {
        System.out.printf("- %s (%d): %s%n", type, names.size(),
                String.join(", ", names));
    });
});
commands.put("fight", (ctx, a) -> {
    Room cur = ctx.getCurrent();
    Monster m = cur.getMonster();
    if (m == null) throw new InvalidCommandException("Здесь нет монстра для боя.");

    Player p = ctx.getPlayer();

    while (p.getHp() > 0 && m.getHp() > 0) {
        // атака игрока
        m.setHp(m.getHp() - p.getAttack());
        System.out.printf("Вы ударили %s на %d. HP монстра: %d%n",
                m.getName(), p.getAttack(), Math.max(0, m.getHp()));
        if (m.getHp() <= 0) break;

        // ответ монстра: урон = level
        p.setHp(p.getHp() - m.getLevel());
        System.out.printf("%s бьёт вас на %d. Ваше HP: %d%n",
                m.getName(), m.getLevel(), Math.max(0, p.getHp()));
    }

    if (p.getHp() <= 0) {
        System.out.println("Вы пали в бою. Игра окончена.");
        System.exit(0);
    } else {
        System.out.println("Монстр повержен!");
        cur.setMonster(null);
    }
});

// сохранение/загрузка/таблица рекордов
commands.put("save", (ctx, a) -> SaveLoad.save(ctx));
commands.put("load", (ctx, a) -> SaveLoad.load(ctx));
commands.put("scores", (ctx, a) -> SaveLoad.printScores());

// корректный выход из игры
commands.put("exit", (ctx, a) -> {
    System.out.println("Пока!");
    System.exit(0);
});
    }

    private void bootstrapWorld() {
        Player hero = new Player("Герой", 20, 5);
        state.setPlayer(hero);

        Room square = new Room("Площадь", "Каменная площадь с фонтаном.");
        Room forest = new Room("Лес", "Шелест листвы и птичий щебет.");
        Room cave = new Room("Пещера", "Темно и сыро.");
        square.getNeighbors().put("north", forest);
        forest.getNeighbors().put("south", square);
        forest.getNeighbors().put("east", cave);
        cave.getNeighbors().put("west", forest);

        forest.getItems().add(new Potion("Малое зелье", 5));
        forest.setMonster(new Monster("Волк", 1, 8));

        state.setCurrent(square);
    }

    public void run() {
    System.out.println("DungeonMini (TEMPLATE). 'help' — команды.");
    try (BufferedReader in = new BufferedReader(
            new InputStreamReader(System.in, StandardCharsets.UTF_8))) {
        while (true) {
                System.out.print("> ");
                String line = in.readLine();
                if (line == null) break;
                line = line.trim();
                if (line.isEmpty()) continue;
                List<String> parts = Arrays.asList(line.split("\\s+"));
                String cmd = parts.get(0).toLowerCase(Locale.ROOT);
                List<String> args = parts.subList(1, parts.size());
                Command c = commands.get(cmd);
                try {
                    if (c == null) throw new InvalidCommandException("Неизвестная команда: " + cmd);
                    c.execute(state, args);
                    state.addScore(1);
                } catch (InvalidCommandException e) {
                    System.out.println("Ошибка: " + e.getMessage());
                } catch (Exception e) {
                    System.out.println("Непредвиденная ошибка: " + e.getClass().getSimpleName() + ": " + e.getMessage());
                }
            }
        } catch (IOException e) {
            System.out.println("Ошибка ввода/вывода: " + e.getMessage());
        }
    }
}
